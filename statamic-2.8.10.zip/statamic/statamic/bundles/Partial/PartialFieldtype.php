<?php

namespace Statamic\Addons\Partial;

use Statamic\Extend\Fieldtype;

class PartialFieldtype extends Fieldtype
{
}
