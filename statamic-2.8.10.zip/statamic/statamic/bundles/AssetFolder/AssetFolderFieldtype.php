<?php

namespace Statamic\Addons\AssetFolder;

use Statamic\Extend\Fieldtype;

class AssetFolderFieldtype extends Fieldtype
{
}
