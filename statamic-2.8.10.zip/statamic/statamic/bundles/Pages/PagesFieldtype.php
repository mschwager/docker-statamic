<?php

namespace Statamic\Addons\Pages;

use Statamic\Addons\Relate\RelateFieldtype;

class PagesFieldtype extends RelateFieldtype
{

}
