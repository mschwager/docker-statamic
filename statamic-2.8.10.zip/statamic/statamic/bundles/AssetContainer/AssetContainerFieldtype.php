<?php

namespace Statamic\Addons\AssetContainer;

use Statamic\Extend\Fieldtype;

class AssetContainerFieldtype extends Fieldtype
{
}
