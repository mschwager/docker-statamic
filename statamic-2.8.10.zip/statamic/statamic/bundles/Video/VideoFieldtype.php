<?php

namespace Statamic\Addons\Video;

use Statamic\Extend\Fieldtype;

class VideoFieldtype extends Fieldtype
{
}
