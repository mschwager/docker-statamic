<?php

namespace Statamic\Addons\Time;

use Statamic\Extend\Fieldtype;

class TimeFieldtype extends Fieldtype
{
}
