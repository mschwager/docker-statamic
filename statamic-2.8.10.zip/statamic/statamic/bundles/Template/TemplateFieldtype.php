<?php

namespace Statamic\Addons\Template;

use Statamic\Extend\Fieldtype;

class TemplateFieldtype extends Fieldtype
{
}
