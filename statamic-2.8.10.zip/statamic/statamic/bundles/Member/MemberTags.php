<?php

namespace Statamic\Addons\Member;

use Statamic\Addons\User\UserTags;

class MemberTags extends UserTags
{

}
