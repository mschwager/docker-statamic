<?php

namespace Statamic\Contracts\Data\Filters;

interface ConditionFilterer
{

}
