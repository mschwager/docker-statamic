<?php

namespace Statamic\Contracts\Data\Services;

interface UsersService
{

}
