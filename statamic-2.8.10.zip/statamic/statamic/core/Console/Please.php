<?php

namespace Statamic\Console;

use Illuminate\Support\Facades\Artisan;

class Please extends Artisan
{
}
