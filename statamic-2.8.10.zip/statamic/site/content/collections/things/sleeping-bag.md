title: Sleeping Bag
id: a3d20755-bb9f-4609-b051-d733cee4081e
amazon_id: B00A2URI7G
photo: http://ecx.images-amazon.com/images/I/4175vsem%2BJL.jpg
